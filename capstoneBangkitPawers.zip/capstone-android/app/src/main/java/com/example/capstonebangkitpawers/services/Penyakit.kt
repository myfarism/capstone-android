package com.example.capstonebangkitpawers.services

data class Penyakit(
    val deskripsi: String? = null,
    val pencegahan: String? = null
)
